//
//  AppDelegate.m
//  LearnOpenGLES
//
//  Created by loyinglin on 16/3/11.
//  Copyright © 2016年 loyinglin. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    return YES;
}

@end
