//
//  AdvanceViewController.h
//  LearnOpenGLES
//
//  Created by loyinglin on 16/3/25.
//  Copyright © 2016年 loyinglin. All rights reserved.
//

#import <GLKit/GLKit.h>

@interface AdvanceViewController : GLKViewController

@end
